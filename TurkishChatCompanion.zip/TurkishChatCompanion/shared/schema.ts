import { pgTable, text, serial, varchar, date, integer, jsonb, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User groups schema
export const userGroups = pgTable("user_groups", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  color: varchar("color", { length: 20 }).default("#4f46e5"), // Default indigo color
});

export const insertUserGroupSchema = createInsertSchema(userGroups).pick({
  name: true,
  description: true,
  color: true,
});

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull().unique(),
  groupId: integer("group_id").references(() => userGroups.id, { onDelete: 'set null' }),
});

export const insertUserSchema = createInsertSchema(users).pick({
  name: true,
  phone: true,
  groupId: true,
});

// Message template categories schema
export const templateCategories = pgTable("template_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
});

export const insertTemplateCategorySchema = createInsertSchema(templateCategories).pick({
  name: true,
  description: true,
});

// Message template schema
export const messageTemplates = pgTable("message_templates", {
  id: serial("id").primaryKey(),
  template: text("template").notNull(),
  categoryId: integer("category_id").references(() => templateCategories.id, { onDelete: 'set null' }),
});

export const insertMessageTemplateSchema = createInsertSchema(messageTemplates).pick({
  template: true,
  categoryId: true,
});

// Config schema
export const config = pgTable("config", {
  id: serial("id").primaryKey(),
  dailyLimitPerAccount: integer("daily_limit_per_account").notNull().default(100),
  accounts: integer("accounts").notNull().default(5),
  messageDelayMin: integer("message_delay_min").notNull().default(30000),
  messageDelayMax: integer("message_delay_max").notNull().default(60000),
});

export const insertConfigSchema = createInsertSchema(config).pick({
  dailyLimitPerAccount: true,
  accounts: true,
  messageDelayMin: true,
  messageDelayMax: true,
});

// Message history schema
export const messageHistory = pgTable("message_history", {
  id: serial("id").primaryKey(),
  phone: varchar("phone", { length: 20 }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  message: text("message").notNull(),
  sentDate: date("sent_date").notNull(),
  groupId: integer("group_id").references(() => userGroups.id, { onDelete: 'set null' }),
});

export const insertMessageHistorySchema = createInsertSchema(messageHistory).pick({
  phone: true,
  name: true,
  message: true,
  sentDate: true,
  groupId: true,
});

// Log schema
export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 20 }).notNull(), // success, error, info
  message: text("message").notNull(),
  timestamp: date("timestamp").notNull(),
});

export const insertLogSchema = createInsertSchema(logs).pick({
  type: true,
  message: true,
  timestamp: true,
});

// Type definitions
export type UserGroup = typeof userGroups.$inferSelect;
export type InsertUserGroup = z.infer<typeof insertUserGroupSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type TemplateCategory = typeof templateCategories.$inferSelect;
export type InsertTemplateCategory = z.infer<typeof insertTemplateCategorySchema>;

export type MessageTemplate = typeof messageTemplates.$inferSelect;
export type InsertMessageTemplate = z.infer<typeof insertMessageTemplateSchema>;

export type Config = typeof config.$inferSelect;
export type InsertConfig = z.infer<typeof insertConfigSchema>;

export type MessageHistoryEntry = typeof messageHistory.$inferSelect;
export type InsertMessageHistoryEntry = z.infer<typeof insertMessageHistorySchema>;

export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;

// Custom types for frontend
export type UserWithStatus = User & {
  status: "sent" | "unsent";
  lastSent: string | null;
  groupName?: string;
};

export type MessageTemplateWithCategory = MessageTemplate & {
  categoryName?: string;
};
