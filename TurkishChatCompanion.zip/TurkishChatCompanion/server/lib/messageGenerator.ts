import { MessageTemplate } from "@shared/schema";

/**
 * Generates a message for a specific user based on available templates
 */
export function generateMessage(name: string, templates: MessageTemplate[] = []): string {
  // If no templates provided, use default templates
  if (templates.length === 0) {
    const defaultTemplates = [
      `Merhaba {name}, size özel bir teklifimiz var!`,
      `{name} Hanım/Bey, bugünkü kampanyamıza göz attınız mı?`,
      `Selam {name}, bonus fırsatları sizi bekliyor!`,
      `{name}, bu fırsatı kaçırmayın. Detaylar için yazın!`
    ];
    
    const template = defaultTemplates[Math.floor(Math.random() * defaultTemplates.length)];
    return template.replace(/{name}/g, name);
  }
  
  // Choose a random template from the provided ones
  const template = templates[Math.floor(Math.random() * templates.length)].template;
  return template.replace(/{name}/g, name);
}
