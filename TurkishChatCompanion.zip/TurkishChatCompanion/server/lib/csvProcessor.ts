import { InsertUser } from "@shared/schema";

/**
 * Processes a CSV file content and converts it to user objects
 */
export async function processCSV(csvContent: string): Promise<InsertUser[]> {
  // Split the CSV content by lines
  const lines = csvContent.split(/\r\n|\n/);
  const headers = lines[0].toLowerCase().split(',');
  
  // Find the indices of name and phone columns
  const nameIndex = headers.findIndex(h => h.trim() === 'name');
  const phoneIndex = headers.findIndex(h => h.trim() === 'phone');
  
  if (nameIndex === -1 || phoneIndex === -1) {
    throw new Error("CSV formatı geçersiz. 'name' ve 'phone' sütunları olmalıdır.");
  }
  
  const users: InsertUser[] = [];
  
  // Process each line (skip the header)
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const values = line.split(',');
    if (values.length <= Math.max(nameIndex, phoneIndex)) {
      continue; // Skip invalid lines
    }
    
    const name = values[nameIndex].trim();
    const phone = values[phoneIndex].trim();
    
    if (name && phone) {
      users.push({ name, phone });
    }
  }
  
  return users;
}
