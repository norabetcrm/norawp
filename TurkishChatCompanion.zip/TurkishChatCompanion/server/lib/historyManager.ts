/**
 * Checks if a message has been sent to a phone number today
 */
export function hasSentToday(sentHistory: Record<string, string>, phone: string): boolean {
  const today = new Date().toISOString().split('T')[0];
  return sentHistory[phone] === today;
}

/**
 * Marks a phone number as having been sent a message today
 */
export function markAsSent(
  sentHistory: Record<string, string>,
  phone: string
): Record<string, string> {
  const today = new Date().toISOString().split('T')[0];
  return {
    ...sentHistory,
    [phone]: today
  };
}
