import { InsertLog } from "@shared/schema";

/**
 * Log types
 */
export enum LogType {
  SUCCESS = "success",
  INFO = "info",
  ERROR = "error"
}

/**
 * Creates a log entry
 */
export function createLog(type: LogType, message: string): InsertLog {
  return {
    type,
    message,
    timestamp: new Date()
  };
}

/**
 * Creates a success log
 */
export function logSuccess(message: string): InsertLog {
  return createLog(LogType.SUCCESS, message);
}

/**
 * Creates an info log
 */
export function logInfo(message: string): InsertLog {
  return createLog(LogType.INFO, message);
}

/**
 * Creates an error log
 */
export function logError(message: string): InsertLog {
  return createLog(LogType.ERROR, message);
}
