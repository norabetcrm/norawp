import { User, UserWithStatus } from "@shared/schema";
import { hasSentToday } from "./historyManager";

/**
 * Filters users by whether they've been sent a message today
 */
export async function filterUnsentUsers(users: User[], sentHistory: Record<string, string>): Promise<UserWithStatus[]> {
  return users.map(user => {
    const today = new Date().toISOString().split('T')[0];
    const hasSent = sentHistory[user.phone] === today;
    
    return {
      ...user,
      status: hasSent ? "sent" : "unsent",
      lastSent: hasSent ? today : null
    };
  });
}

/**
 * Returns users that haven't received a message today
 */
export async function getUnsentUsers(users: User[], sentHistory: Record<string, string>): Promise<UserWithStatus[]> {
  const usersWithStatus = await filterUnsentUsers(users, sentHistory);
  return usersWithStatus.filter(user => user.status === "unsent");
}
