/**
 * Calculates how many users to send messages to based on daily limit per account
 */
export function getLimitPerAccount(
  totalUsers: number,
  accounts: number,
  dailyLimitPerAccount: number
): number {
  const max = dailyLimitPerAccount * accounts;
  return totalUsers > max ? max : totalUsers;
}
