/**
 * Tarih formatları için yardımcı fonksiyonlar
 */

/**
 * Date nesnesini ISO string formatına dönüştürür
 * @param date - Date nesnesi
 * @returns ISO string formatında tarih
 */
export function toISOString(date: Date): string {
  return date.toISOString();
}

/**
 * Bugünün tarihini ISO string formatında döndürür 
 */
export function getNowAsISOString(): string {
  return new Date().toISOString();
}

/**
 * Belirli bir tarih verilen tarihte mi kontrol eder (saat ve dakikayı dikkate almadan)
 */
export function isSameDay(date1: string | Date, date2: string | Date): boolean {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  
  return (
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate()
  );
}

/**
 * Belirli bir tarih bugün mü kontrol eder
 */
export function isToday(date: string | Date): boolean {
  return isSameDay(date, new Date());
}

/**
 * Bir tarih stringini insanların okuyabileceği formata dönüştürür
 */
export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleString('tr-TR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}