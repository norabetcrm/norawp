import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertMessageTemplateSchema, 
  insertConfigSchema,
  insertUserGroupSchema,
  insertTemplateCategorySchema
} from "@shared/schema";
import multer from "multer";
import fs from "fs";
import path from "path";
import { processCSV } from "./lib/csvProcessor";
import { generateMessage } from "./lib/messageGenerator";
import { formatDate, getNowAsISOString } from "./lib/dateUtils";
import { getLimitPerAccount } from "./lib/limiter";
import { filterUnsentUsers, getUnsentUsers } from "./lib/userManager";
import { markAsSent } from "./lib/historyManager";

// Setup multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // Limit to 5MB
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Users API
  app.get("/api/users", async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsersWithStatus();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const parseResult = insertUserSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Invalid user data", errors: parseResult.error });
      }
      
      const user = await storage.createUser(parseResult.data);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.delete("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const result = await storage.deleteUser(id);
      if (result) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // CSV Upload
  app.post("/api/users/csv", upload.single("file"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const csvContent = req.file.buffer.toString("utf-8");
      const users = await processCSV(csvContent);
      
      // Save users to storage
      const savedUsers = [];
      for (const user of users) {
        savedUsers.push(await storage.createUser(user));
      }
      
      res.status(201).json({ message: `Imported ${savedUsers.length} users`, users: savedUsers });
    } catch (error) {
      res.status(500).json({ message: `Failed to process CSV: ${error}` });
    }
  });

  // Message Templates API
  app.get("/api/templates", async (req: Request, res: Response) => {
    try {
      const templates = await storage.getMessageTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch message templates" });
    }
  });

  app.post("/api/templates", async (req: Request, res: Response) => {
    try {
      const parseResult = insertMessageTemplateSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Invalid template data", errors: parseResult.error });
      }
      
      const template = await storage.createMessageTemplate(parseResult.data);
      res.status(201).json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to create message template" });
    }
  });

  app.put("/api/templates/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid template ID" });
      }
      
      const parseResult = insertMessageTemplateSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Invalid template data", errors: parseResult.error });
      }
      
      const template = await storage.updateMessageTemplate(id, parseResult.data);
      if (template) {
        res.json(template);
      } else {
        res.status(404).json({ message: "Template not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to update template" });
    }
  });

  app.delete("/api/templates/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid template ID" });
      }
      
      const result = await storage.deleteMessageTemplate(id);
      if (result) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Template not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete template" });
    }
  });

  // Config API
  app.get("/api/config", async (req: Request, res: Response) => {
    try {
      const config = await storage.getConfig();
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch config" });
    }
  });

  app.put("/api/config", async (req: Request, res: Response) => {
    try {
      const parseResult = insertConfigSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Invalid config data", errors: parseResult.error });
      }
      
      const config = await storage.updateConfig(parseResult.data);
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to update config" });
    }
  });

  // Message History API
  app.get("/api/history", async (req: Request, res: Response) => {
    try {
      const history = await storage.getMessageHistory();
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch message history" });
    }
  });

  app.delete("/api/history", async (req: Request, res: Response) => {
    try {
      await storage.clearMessageHistory();
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to clear message history" });
    }
  });

  // Logs API
  app.get("/api/logs", async (req: Request, res: Response) => {
    try {
      const logs = await storage.getLogs();
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch logs" });
    }
  });

  app.delete("/api/logs", async (req: Request, res: Response) => {
    try {
      await storage.clearLogs();
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to clear logs" });
    }
  });

  // User Groups API
  app.get("/api/groups", async (req: Request, res: Response) => {
    try {
      const groups = await storage.getUserGroups();
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Kullanıcı grupları alınamadı" });
    }
  });

  app.post("/api/groups", async (req: Request, res: Response) => {
    try {
      const parseResult = insertUserGroupSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Geçersiz grup verisi", errors: parseResult.error });
      }
      
      const group = await storage.createUserGroup(parseResult.data);
      res.status(201).json(group);
    } catch (error) {
      res.status(500).json({ message: "Grup oluşturulamadı" });
    }
  });

  app.put("/api/groups/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz grup kimliği" });
      }
      
      const parseResult = insertUserGroupSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Geçersiz grup verisi", errors: parseResult.error });
      }
      
      const group = await storage.updateUserGroup(id, parseResult.data);
      if (group) {
        res.json(group);
      } else {
        res.status(404).json({ message: "Grup bulunamadı" });
      }
    } catch (error) {
      res.status(500).json({ message: "Grup güncellenemedi" });
    }
  });

  app.delete("/api/groups/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz grup kimliği" });
      }
      
      const result = await storage.deleteUserGroup(id);
      if (result) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Grup bulunamadı" });
      }
    } catch (error) {
      res.status(500).json({ message: "Grup silinemedi" });
    }
  });

  app.get("/api/groups/:id/users", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz grup kimliği" });
      }
      
      const users = await storage.getUsersByGroup(id);
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Gruptaki kullanıcılar alınamadı" });
    }
  });

  // Template Categories API
  app.get("/api/categories", async (req: Request, res: Response) => {
    try {
      const categories = await storage.getTemplateCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Şablon kategorileri alınamadı" });
    }
  });

  app.post("/api/categories", async (req: Request, res: Response) => {
    try {
      const parseResult = insertTemplateCategorySchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Geçersiz kategori verisi", errors: parseResult.error });
      }
      
      const category = await storage.createTemplateCategory(parseResult.data);
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: "Kategori oluşturulamadı" });
    }
  });

  app.put("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz kategori kimliği" });
      }
      
      const parseResult = insertTemplateCategorySchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ message: "Geçersiz kategori verisi", errors: parseResult.error });
      }
      
      const category = await storage.updateTemplateCategory(id, parseResult.data);
      if (category) {
        res.json(category);
      } else {
        res.status(404).json({ message: "Kategori bulunamadı" });
      }
    } catch (error) {
      res.status(500).json({ message: "Kategori güncellenemedi" });
    }
  });

  app.delete("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Geçersiz kategori kimliği" });
      }
      
      const result = await storage.deleteTemplateCategory(id);
      if (result) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: "Kategori bulunamadı" });
      }
    } catch (error) {
      res.status(500).json({ message: "Kategori silinemedi" });
    }
  });

  // Enhanced Templates API
  app.get("/api/templates/categories", async (req: Request, res: Response) => {
    try {
      const templates = await storage.getMessageTemplatesWithCategories();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Kategorilendirilmiş şablonlar alınamadı" });
    }
  });

  // Messaging Simulation API
  app.post("/api/simulate/start", async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsersWithStatus();
      const config = await storage.getConfig();
      const templates = await storage.getMessageTemplatesWithCategories();
      
      // Get group specific settings from request, if any
      const { groupId } = req.body;
      
      // Filter by group if provided
      let filteredUsers = users;
      if (groupId) {
        const groupIdNum = parseInt(groupId);
        if (!isNaN(groupIdNum)) {
          filteredUsers = users.filter(user => user.groupId === groupIdNum);
          
          // Log group filtering
          await storage.createLog({
            type: "info",
            message: `Sadece "${users.find(u => u.groupId === groupIdNum)?.groupName}" grubundaki kullanıcılara gönderim yapılıyor`,
            timestamp: getNowAsISOString(),
          });
        }
      }
      
      // Filter out users who have already received messages today
      const unsentUsers = filteredUsers.filter(user => user.status === "unsent");
      
      // Calculate the number of users to send messages to based on daily limit
      const totalToSend = getLimitPerAccount(unsentUsers.length, config.accounts, config.dailyLimitPerAccount);
      const selectedUsers = unsentUsers.slice(0, totalToSend);
      
      if (selectedUsers.length === 0) {
        await storage.createLog({
          type: "info",
          message: "Gönderilecek mesaj için uygun kullanıcı bulunamadı",
          timestamp: getNowAsISOString(),
        });
        
        return res.json({ 
          success: true, 
          message: "Gönderilecek mesaj için uygun kullanıcı bulunamadı", 
          totalSelected: 0 
        });
      }
      
      // Log the start of the operation
      await storage.createLog({
        type: "info",
        message: `Toplam gönderilecek kullanıcı sayısı: ${selectedUsers.length}`,
        timestamp: getNowAsISOString(),
      });
      
      // Start the simulation in the background
      res.json({ 
        success: true, 
        message: "Mesaj gönderim simülasyonu başlatıldı", 
        totalSelected: selectedUsers.length 
      });
      
      // Process messages in sequence with delays
      for (let i = 0; i < selectedUsers.length; i++) {
        const user = selectedUsers[i];
        
        // Generate a message for this user
        const message = generateMessage(user.name, templates);
        
        // Log the sent message
        await storage.createLog({
          type: "success",
          message: `Mesaj gönderildi → ${user.name}${user.groupName ? ` (${user.groupName})` : ''}: "${message}"`,
          timestamp: getNowAsISOString(),
        });
        
        // Add to history
        await storage.createMessageHistoryEntry({
          phone: user.phone,
          name: user.name,
          message,
          sentDate: getNowAsISOString(),
          groupId: user.groupId,
        });
        
        // Wait before sending the next message if not the last message
        if (i < selectedUsers.length - 1) {
          const delay = Math.floor(
            Math.random() * (config.messageDelayMax - config.messageDelayMin)
          ) + config.messageDelayMin;
          
          await storage.createLog({
            type: "info",
            message: `Bekleniyor (${delay / 1000} saniye)...`,
            timestamp: getNowAsISOString(),
          });
          
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      
      // Log completion
      await storage.createLog({
        type: "info",
        message: "✔️ Gönderim simülasyonu tamamlandı.",
        timestamp: getNowAsISOString(),
      });
      
    } catch (error) {
      await storage.createLog({
        type: "error",
        message: `Simülasyon hatası: ${error}`,
        timestamp: getNowAsISOString(),
      });
      
      res.status(500).json({ message: "Mesaj gönderim simülasyonu başlatılamadı" });
    }
  });

  // Test message API
  app.post("/api/simulate/test", async (req: Request, res: Response) => {
    try {
      const { phone, name, message, groupId } = req.body;
      
      if (!phone || !name || !message) {
        return res.status(400).json({ message: "Telefon, isim ve mesaj gereklidir" });
      }
      
      // Find the group if provided
      let groupName = "";
      if (groupId) {
        const groups = await storage.getUserGroups();
        const group = groups.find(g => g.id === parseInt(groupId));
        if (group) {
          groupName = group.name;
        }
      }
      
      // Log the test message
      await storage.createLog({
        type: "success",
        message: `Test mesajı gönderildi → ${name}${groupName ? ` (${groupName})` : ''}: "${message}"`,
        timestamp: getNowAsISOString(),
      });
      
      res.json({ success: true, message: "Test mesajı gönderildi" });
    } catch (error) {
      res.status(500).json({ message: "Test mesajı gönderilemedi" });
    }
  });

  // Export users to CSV
  app.get("/api/users/csv", async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsers();
      const groups = await storage.getUserGroups();
      
      // Create CSV content with group info
      let csvContent = "name,phone,group\n";
      users.forEach(user => {
        const group = user.groupId ? groups.find(g => g.id === user.groupId)?.name || "" : "";
        csvContent += `${user.name},${user.phone},${group}\n`;
      });
      
      // Set headers for file download
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=users.csv");
      
      res.send(csvContent);
    } catch (error) {
      res.status(500).json({ message: "Failed to export users to CSV" });
    }
  });

  // Export logs to a text file
  app.get("/api/logs/export", async (req: Request, res: Response) => {
    try {
      const logs = await storage.getLogs();
      
      // Create log content
      let logContent = "";
      logs.forEach(log => {
        const timestamp = formatDate(log.timestamp);
        logContent += `[${timestamp}] [${log.type.toUpperCase()}] ${log.message}\n`;
      });
      
      // Set headers for file download
      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", "attachment; filename=logs.txt");
      
      res.send(logContent);
    } catch (error) {
      res.status(500).json({ message: "Failed to export logs" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
