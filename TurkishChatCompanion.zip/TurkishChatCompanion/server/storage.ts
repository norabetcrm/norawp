import {
  User, InsertUser, 
  UserGroup, InsertUserGroup,
  TemplateCategory, InsertTemplateCategory,
  MessageTemplate, InsertMessageTemplate,
  Config, InsertConfig,
  MessageHistoryEntry, InsertMessageHistoryEntry,
  Log, InsertLog,
  UserWithStatus, MessageTemplateWithCategory,
  users, userGroups, templateCategories, messageTemplates, 
  config, messageHistory, logs
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, isNull } from "drizzle-orm";

export interface IStorage {
  // User group operations
  getUserGroups(): Promise<UserGroup[]>;
  createUserGroup(group: InsertUserGroup): Promise<UserGroup>;
  updateUserGroup(id: number, group: Partial<UserGroup>): Promise<UserGroup | undefined>;
  deleteUserGroup(id: number): Promise<boolean>;
  
  // User operations
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // Template category operations
  getTemplateCategories(): Promise<TemplateCategory[]>;
  createTemplateCategory(category: InsertTemplateCategory): Promise<TemplateCategory>;
  updateTemplateCategory(id: number, category: Partial<TemplateCategory>): Promise<TemplateCategory | undefined>;
  deleteTemplateCategory(id: number): Promise<boolean>;
  
  // Message templates operations
  getMessageTemplates(): Promise<MessageTemplate[]>;
  getMessageTemplatesWithCategories(): Promise<MessageTemplateWithCategory[]>;
  createMessageTemplate(template: InsertMessageTemplate): Promise<MessageTemplate>;
  updateMessageTemplate(id: number, template: Partial<MessageTemplate>): Promise<MessageTemplate | undefined>;
  deleteMessageTemplate(id: number): Promise<boolean>;
  
  // Config operations
  getConfig(): Promise<Config>;
  updateConfig(config: Partial<Config>): Promise<Config>;
  
  // Message history operations
  getMessageHistory(): Promise<MessageHistoryEntry[]>;
  createMessageHistoryEntry(entry: InsertMessageHistoryEntry): Promise<MessageHistoryEntry>;
  clearMessageHistory(): Promise<boolean>;
  
  // Log operations
  getLogs(): Promise<Log[]>;
  createLog(log: InsertLog): Promise<Log>;
  clearLogs(): Promise<boolean>;
  
  // Combined operations
  getUsersWithStatus(): Promise<UserWithStatus[]>;
  getUsersByGroup(groupId: number): Promise<User[]>;
  hasSentToday(phone: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User group operations
  async getUserGroups(): Promise<UserGroup[]> {
    return db.select().from(userGroups).orderBy(userGroups.id);
  }

  async createUserGroup(group: InsertUserGroup): Promise<UserGroup> {
    const [result] = await db.insert(userGroups).values(group).returning();
    return result;
  }

  async updateUserGroup(id: number, groupData: Partial<UserGroup>): Promise<UserGroup | undefined> {
    const [result] = await db
      .update(userGroups)
      .set(groupData)
      .where(eq(userGroups.id, id))
      .returning();
    return result;
  }

  async deleteUserGroup(id: number): Promise<boolean> {
    const [result] = await db
      .delete(userGroups)
      .where(eq(userGroups.id, id))
      .returning();
    return !!result;
  }

  // User operations
  async getUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(users.id);
  }

  async getUsersByGroup(groupId: number): Promise<User[]> {
    return db
      .select()
      .from(users)
      .where(eq(users.groupId, groupId))
      .orderBy(users.id);
  }

  async createUser(user: InsertUser): Promise<User> {
    const [result] = await db.insert(users).values(user).returning();
    return result;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [result] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return result;
  }

  async deleteUser(id: number): Promise<boolean> {
    const [result] = await db
      .delete(users)
      .where(eq(users.id, id))
      .returning();
    return !!result;
  }

  // Template category operations
  async getTemplateCategories(): Promise<TemplateCategory[]> {
    return db.select().from(templateCategories).orderBy(templateCategories.id);
  }

  async createTemplateCategory(category: InsertTemplateCategory): Promise<TemplateCategory> {
    const [result] = await db.insert(templateCategories).values(category).returning();
    return result;
  }

  async updateTemplateCategory(id: number, categoryData: Partial<TemplateCategory>): Promise<TemplateCategory | undefined> {
    const [result] = await db
      .update(templateCategories)
      .set(categoryData)
      .where(eq(templateCategories.id, id))
      .returning();
    return result;
  }

  async deleteTemplateCategory(id: number): Promise<boolean> {
    const [result] = await db
      .delete(templateCategories)
      .where(eq(templateCategories.id, id))
      .returning();
    return !!result;
  }

  // Message templates operations
  async getMessageTemplates(): Promise<MessageTemplate[]> {
    return db.select().from(messageTemplates).orderBy(messageTemplates.id);
  }

  async getMessageTemplatesWithCategories(): Promise<MessageTemplateWithCategory[]> {
    const templates = await this.getMessageTemplates();
    const categories = await this.getTemplateCategories();
    
    return templates.map(template => {
      const category = categories.find(cat => cat.id === template.categoryId);
      return {
        ...template,
        categoryName: category?.name
      };
    });
  }

  async createMessageTemplate(template: InsertMessageTemplate): Promise<MessageTemplate> {
    const [result] = await db.insert(messageTemplates).values(template).returning();
    return result;
  }

  async updateMessageTemplate(id: number, templateData: Partial<MessageTemplate>): Promise<MessageTemplate | undefined> {
    const [result] = await db
      .update(messageTemplates)
      .set(templateData)
      .where(eq(messageTemplates.id, id))
      .returning();
    return result;
  }

  async deleteMessageTemplate(id: number): Promise<boolean> {
    const [result] = await db
      .delete(messageTemplates)
      .where(eq(messageTemplates.id, id))
      .returning();
    return !!result;
  }

  // Config operations
  async getConfig(): Promise<Config> {
    const [result] = await db.select().from(config).limit(1);
    return result || this.createDefaultConfig();
  }

  private async createDefaultConfig(): Promise<Config> {
    const defaultConfig: InsertConfig = {
      dailyLimitPerAccount: 100,
      accounts: 5,
      messageDelayMin: 30000,
      messageDelayMax: 60000,
    };
    const [result] = await db.insert(config).values(defaultConfig).returning();
    return result;
  }

  async updateConfig(configData: Partial<Config>): Promise<Config> {
    const currentConfig = await this.getConfig();
    
    const [result] = await db
      .update(config)
      .set(configData)
      .where(eq(config.id, currentConfig.id))
      .returning();
      
    return result;
  }

  // Message history operations
  async getMessageHistory(): Promise<MessageHistoryEntry[]> {
    return db.select().from(messageHistory).orderBy(desc(messageHistory.id));
  }

  async createMessageHistoryEntry(entry: InsertMessageHistoryEntry): Promise<MessageHistoryEntry> {
    const [result] = await db.insert(messageHistory).values(entry).returning();
    return result;
  }

  async clearMessageHistory(): Promise<boolean> {
    await db.delete(messageHistory);
    return true;
  }

  // Log operations
  async getLogs(): Promise<Log[]> {
    return db.select().from(logs).orderBy(desc(logs.id));
  }

  async createLog(log: InsertLog): Promise<Log> {
    const [result] = await db.insert(logs).values(log).returning();
    return result;
  }

  async clearLogs(): Promise<boolean> {
    await db.delete(logs);
    return true;
  }

  // Combined operations
  async getUsersWithStatus(): Promise<UserWithStatus[]> {
    const allUsers = await this.getUsers();
    const history = await this.getMessageHistory();
    const allGroups = await this.getUserGroups();
    
    return Promise.all(allUsers.map(async (user) => {
      const userHistory = history.filter(entry => entry.phone === user.phone);
      const lastSentEntry = userHistory.length > 0 ? 
        userHistory.sort((a, b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime())[0] : 
        null;
      
      const today = new Date().toISOString().split('T')[0];
      const status = lastSentEntry && lastSentEntry.sentDate.toString().includes(today) ? "sent" : "unsent";
      
      // Get group name if user has a group
      const userGroup = user.groupId ? allGroups.find(g => g.id === user.groupId) : undefined;
      
      return {
        ...user,
        status,
        lastSent: lastSentEntry ? lastSentEntry.sentDate.toString() : null,
        groupName: userGroup?.name
      };
    }));
  }

  async hasSentToday(phone: string): Promise<boolean> {
    const today = new Date().toISOString().split('T')[0];
    
    const entries = await db
      .select()
      .from(messageHistory)
      .where(eq(messageHistory.phone, phone));
      
    return entries.some(entry => entry.sentDate.toString().includes(today));
  }

  // Helper method to initialize data
  async initializeData(): Promise<void> {
    // Initialize default user groups
    const groups = await db.select().from(userGroups).execute();
    if (groups.length === 0) {
      // Create default groups
      await this.createUserGroup({ 
        name: "Müşteriler", 
        description: "Aktif müşteriler",
        color: "#4f46e5" // indigo
      });
      await this.createUserGroup({ 
        name: "Potansiyel Müşteriler", 
        description: "Henüz satın almamış potansiyel müşteriler",
        color: "#10b981" // emerald
      });
      await this.createUserGroup({ 
        name: "Eski Müşteriler", 
        description: "Uzun süredir aktif olmayan müşteriler",
        color: "#f59e0b" // amber
      });
    }
    
    // Initialize default template categories
    const categories = await db.select().from(templateCategories).execute();
    if (categories.length === 0) {
      // Create default categories
      await this.createTemplateCategory({ 
        name: "Kampanya", 
        description: "Kampanya ve indirim bildirimleri"
      });
      await this.createTemplateCategory({ 
        name: "Bilgilendirme", 
        description: "Bilgilendirme mesajları"
      });
      await this.createTemplateCategory({ 
        name: "Hatırlatma", 
        description: "Hatırlatma mesajları"
      });
    }
    
    // Check if users already exist
    const usersCount = await db.select().from(users).execute();
    if (usersCount.length === 0) {
      // Get first group id
      const [firstGroup] = await db.select().from(userGroups).limit(1);
      const firstGroupId = firstGroup?.id;
      
      // Add default users
      await this.createUser({ name: "Aslı", phone: "+905555000001", groupId: firstGroupId });
      await this.createUser({ name: "Mehmet", phone: "+905555000002", groupId: firstGroupId });
      await this.createUser({ name: "Cansu", phone: "+905555000003", groupId: firstGroupId });
    }
    
    // Check if templates exist
    const templates = await db.select().from(messageTemplates).execute();
    if (templates.length === 0) {
      // Get first category id
      const [firstCategory] = await db.select().from(templateCategories).limit(1);
      const firstCategoryId = firstCategory?.id;
      
      // Add default templates
      await this.createMessageTemplate({ 
        template: "Merhaba {name}, size özel bir teklifimiz var!", 
        categoryId: firstCategoryId 
      });
      await this.createMessageTemplate({ 
        template: "{name} Hanım/Bey, bugünkü kampanyamıza göz attınız mı?",
        categoryId: firstCategoryId
      });
      await this.createMessageTemplate({ 
        template: "Selam {name}, bonus fırsatları sizi bekliyor!",
        categoryId: firstCategoryId
      });
      await this.createMessageTemplate({ 
        template: "{name}, bu fırsatı kaçırmayın. Detaylar için yazın!",
        categoryId: firstCategoryId
      });
    }
    
    // Make sure config exists
    await this.getConfig();
  }
}

// Initialize database storage with sample data
const dbStorage = new DatabaseStorage();
dbStorage.initializeData().catch(console.error);

export const storage = dbStorage;
