-- Kullanıcılar için indeksler
CREATE INDEX IF NOT EXISTS idx_users_group_id ON users(group_id);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);

-- Mesaj şablonları için indeksler
CREATE INDEX IF NOT EXISTS idx_message_templates_category_id ON message_templates(category_id);

-- Mesaj geçmişi için indeksler
CREATE INDEX IF NOT EXISTS idx_message_history_created_at ON message_history(created_at);
CREATE INDEX IF NOT EXISTS idx_message_history_phone ON message_history(phone);

-- Loglar için indeksler
CREATE INDEX IF NOT EXISTS idx_logs_type ON logs(type);
CREATE INDEX IF NOT EXISTS idx_logs_created_at ON logs(created_at);