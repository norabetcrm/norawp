import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AppHeader from "@/components/AppHeader";
import ConfigPanel from "@/components/ConfigPanel";
import MessageTemplates from "@/components/MessageTemplates";
import TemplateCategories from "@/components/TemplateCategories";
import Controls from "@/components/Controls";
import UserList from "@/components/UserList";
import GroupManager from "@/components/GroupManager";
import LogViewer from "@/components/LogViewer";
import HistoryViewer from "@/components/HistoryViewer";
import Footer from "@/components/Footer";
import TestMessageModal from "@/components/TestMessageModal";
import Stats from "@/components/Stats";
import { UserWithStatus } from "@shared/schema";

export default function Home() {
  const [testModalOpen, setTestModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserWithStatus | null>(null);
  const [operationRunning, setOperationRunning] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0, percentage: 0 });

  const handleTestUser = (user: UserWithStatus) => {
    setSelectedUser(user);
    setTestModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <AppHeader />

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex-grow">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Configuration and Control */}
          <div className="lg:col-span-1 space-y-6">
            <ConfigPanel />
            
            <Tabs defaultValue="templates">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="templates">Şablonlar</TabsTrigger>
                <TabsTrigger value="categories">Kategoriler</TabsTrigger>
              </TabsList>
              <TabsContent value="templates" className="mt-2">
                <MessageTemplates />
              </TabsContent>
              <TabsContent value="categories" className="mt-2">
                <TemplateCategories />
              </TabsContent>
            </Tabs>
            
            <Controls 
              operationRunning={operationRunning}
              setOperationRunning={setOperationRunning}
              progress={progress}
              setProgress={setProgress}
            />
            <Stats />
          </div>

          {/* Right Column - Data Display and Logs */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="userlist">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="userlist">Kullanıcı Listesi</TabsTrigger>
                <TabsTrigger value="groups">Kullanıcı Grupları</TabsTrigger>
              </TabsList>
              <TabsContent value="userlist" className="mt-2">
                <UserList onTestUser={handleTestUser} />
              </TabsContent>
              <TabsContent value="groups" className="mt-2">
                <GroupManager />
              </TabsContent>
            </Tabs>
            
            <LogViewer />
            <HistoryViewer />
          </div>
        </div>
      </main>

      <Footer />

      <TestMessageModal 
        isOpen={testModalOpen} 
        onClose={() => setTestModalOpen(false)} 
        user={selectedUser}
      />
    </div>
  );
}
