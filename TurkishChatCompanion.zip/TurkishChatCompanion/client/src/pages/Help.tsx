import { Link } from "wouter";
import AppHeader from "@/components/AppHeader";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, HelpCircle, FileText, User, MessageSquare, Settings, BarChart } from "lucide-react";

export default function Help() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <AppHeader />

      <main className="max-w-5xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex-grow">
        <div className="flex items-center mb-6">
          <Link to="/">
            <Button variant="ghost" className="mr-2">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Geri Dön
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Yardım ve Kullanım Kılavuzu</h1>
        </div>

        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <HelpCircle className="h-5 w-5 mr-2" />
                Uygulama Hakkında
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                WhatsApp Mesaj Gönderim Simülatörü, WhatsApp üzerinden otomatik ve kişiselleştirilmiş mesaj gönderimini 
                simüle etmek için tasarlanmış bir araçtır. Bu uygulama, gerçek WhatsApp API entegrasyonu olmadan 
                mesaj gönderim senaryolarını test etmenizi sağlar.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2" />
                Kullanıcı Listesi Yönetimi
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">CSV Kullanıcı Listesi</h3>
                <p className="text-muted-foreground">
                  Kullanıcı listesini "CSV Yükle" butonu ile içe aktarabilirsiniz. CSV dosyanızda en azından 
                  "name" ve "phone" sütunları bulunmalıdır. Örnek:
                </p>
                <pre className="bg-muted p-2 rounded-md mt-2 overflow-x-auto">
                  <code>
                    name,phone<br/>
                    Ahmet,+905551234567<br/>
                    Ayşe,+905557654321
                  </code>
                </pre>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Test Mesajı Gönderme</h3>
                <p className="text-muted-foreground">
                  Kullanıcı listesinde bir kişiye "Test Et" butonuna tıklayarak test mesajı gönderebilirsiniz.
                  Bu, gerçek bir gönderim değil, sadece bir simülasyondur.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                Mesaj Şablonları
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Mesaj şablonlarınızda kişiselleştirme için {"{name}"} ifadesini kullanabilirsiniz. 
                Kullanıcının adı ile değiştirilecektir.
              </p>
              <p className="text-muted-foreground">
                Örnek: "Merhaba {"{name}"}, size özel bir teklifimiz var!"
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                Konfigürasyon Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Hesap Sayısı</h3>
                <p className="text-muted-foreground">
                  Simülasyonda kullanılacak WhatsApp hesap sayısını belirler. 
                  Bu, günlük maksimum mesaj kapasitesini hesaplamak için kullanılır.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Günlük Limit (Hesap Başına)</h3>
                <p className="text-muted-foreground">
                  Her bir WhatsApp hesabı için günlük maksimum mesaj sayısını belirler. 
                  Toplam günlük kapasite = Hesap Sayısı x Günlük Limit
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Minimum ve Maksimum Gecikme</h3>
                <p className="text-muted-foreground">
                  Mesajlar arasındaki gecikme süresini milisaniye cinsinden belirler. 
                  Bu değerler arasında rastgele bir süre seçilir.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart className="h-5 w-5 mr-2" />
                Gönderim Simülasyonu
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Simülasyonu Başlatma</h3>
                <p className="text-muted-foreground">
                  "Başlat" butonuna tıklayarak mesaj gönderim simülasyonunu başlatabilirsiniz. 
                  Sistem, yapılandırma ayarlarınıza göre maksimum günlük kapasiteyi hesaplayacak 
                  ve henüz mesaj gönderilmemiş kişileri seçecektir.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">İşlem Logları</h3>
                <p className="text-muted-foreground">
                  Tüm işlemler log panelinde izlenebilir. Başarılı mesaj gönderimleri, hatalar ve 
                  diğer bilgiler burada görüntülenir. Logları filtreleyebilir veya indirebilirsiniz.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Gönderim Geçmişi</h3>
                <p className="text-muted-foreground">
                  Gönderim geçmişi panelinde tüm gönderim detaylarını görebilirsiniz. 
                  Kime, ne zaman, hangi mesajın gönderildiği burada listelenir.
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Veri İşlemleri
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Veri Dışa Aktarma</h3>
                <p className="text-muted-foreground">
                  Kullanıcı listesini CSV olarak indirebilirsiniz. Ayrıca log kayıtlarını da metin dosyası olarak 
                  dışa aktarabilirsiniz.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Geçmiş ve Log Temizleme</h3>
                <p className="text-muted-foreground">
                  Gönderim geçmişini ve log kayıtlarını ilgili panellerdeki "Temizle" butonlarıyla silebilirsiniz.
                  Gönderim geçmişini sildiğinizde, tüm kullanıcılar "gönderilmemiş" statüsüne döner.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}