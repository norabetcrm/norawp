import { InsertUser } from "@shared/schema";

/**
 * Parses CSV data from string
 */
export function parseCSV(csvContent: string): InsertUser[] {
  // Split content by new lines
  const lines = csvContent.split(/\r\n|\n/);
  if (lines.length < 2) return [];
  
  // Get headers
  const headers = lines[0].split(',');
  const nameIndex = headers.findIndex(h => h.toLowerCase().trim() === 'name');
  const phoneIndex = headers.findIndex(h => h.toLowerCase().trim() === 'phone');
  
  if (nameIndex === -1 || phoneIndex === -1) {
    throw new Error('CSV dosyası geçersiz format. "name" ve "phone" sütunları gerekli.');
  }
  
  // Parse data rows
  const users: InsertUser[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const values = line.split(',');
    if (values.length <= Math.max(nameIndex, phoneIndex)) continue;
    
    const name = values[nameIndex].trim();
    const phone = values[phoneIndex].trim();
    
    if (name && phone) {
      users.push({ name, phone });
    }
  }
  
  return users;
}
