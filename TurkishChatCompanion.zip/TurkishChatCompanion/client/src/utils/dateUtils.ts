/**
 * Tarih formatları için yardımcı fonksiyonlar
 */

/**
 * Verilen tarihi yerelleştirilmiş (localized) formatta döndürür
 * @param date - ISO string, Date nesnesi veya timestamp
 * @param includeTime - Zamanı da dahil etmek için true, sadece tarih için false
 * @returns Formatlanmış tarih string'i
 */
export function formatDate(date: string | Date | number, includeTime: boolean = true): string {
  if (!date) return "";
  
  const dateObj = typeof date === "string" ? new Date(date) : 
                 date instanceof Date ? date : 
                 new Date(date);
  
  if (isNaN(dateObj.getTime())) return "";
  
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    ...(includeTime && {
      hour: '2-digit',
      minute: '2-digit'
    })
  };
  
  return dateObj.toLocaleDateString('tr-TR', options);
}

/**
 * Date nesnesini ISO string formatına dönüştürür
 * @param date - Date nesnesi
 * @returns ISO string formatında tarih
 */
export function toISOString(date: Date): string {
  return date.toISOString();
}

/**
 * Bugünün tarihini ISO string formatında döndürür
 * @returns ISO string formatında bugünün tarihi
 */
export function getTodayISOString(): string {
  return new Date().toISOString();
}

/**
 * İki tarih arasında günlerin farkını hesaplar
 * @param date1 - Birinci tarih
 * @param date2 - İkinci tarih (verilmezse bugün kabul edilir)
 * @returns Gün farkı
 */
export function daysBetween(date1: string | Date, date2?: string | Date): number {
  const d1 = new Date(date1);
  const d2 = date2 ? new Date(date2) : new Date();
  
  // Her iki tarihi de günün başlangıcına ayarla
  d1.setHours(0, 0, 0, 0);
  d2.setHours(0, 0, 0, 0);
  
  // Milisaniye cinsinden farkı hesapla ve gün sayısına dönüştür
  const diffTime = Math.abs(d2.getTime() - d1.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Verilen tarihin bugün olup olmadığını kontrol eder
 * @param date - Kontrol edilecek tarih
 * @returns Bugün ise true, değilse false
 */
export function isToday(date: string | Date): boolean {
  return daysBetween(date) === 0;
}