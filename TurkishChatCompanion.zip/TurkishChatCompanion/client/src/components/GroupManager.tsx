import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

import { UserGroup } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useForm } from "react-hook-form";
import { LuPlus, LuTrash2, LuUsers, LuPencil, LuCheck, LuX } from "react-icons/lu";

// Renk seçenekleri
const colorOptions = [
  { value: "#4f46e5", label: "Lacivert", className: "bg-indigo-600" },
  { value: "#10b981", label: "Yeşil", className: "bg-emerald-500" },
  { value: "#f59e0b", label: "Turuncu", className: "bg-amber-500" },
  { value: "#ef4444", label: "Kırmızı", className: "bg-red-500" },
  { value: "#6366f1", label: "Mor", className: "bg-violet-500" },
  { value: "#0ea5e9", label: "Mavi", className: "bg-sky-500" },
  { value: "#d946ef", label: "Pembe", className: "bg-fuchsia-500" },
  { value: "#14b8a6", label: "Turkuaz", className: "bg-teal-500" },
];

export default function GroupManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState<number | null>(null);
  const [newGroup, setNewGroup] = useState<Partial<UserGroup>>({
    name: "",
    description: "",
    color: "#4f46e5"
  });
  
  // Form temizleme
  const resetNewGroup = () => {
    setNewGroup({
      name: "",
      description: "",
      color: "#4f46e5"
    });
  };
  
  // Kullanıcı gruplarını çek
  const { data: groups = [] } = useQuery<UserGroup[]>({
    queryKey: ['/api/groups'],
    staleTime: 10000,
  });

  // Yeni grup oluşturma
  const createGroupMutation = useMutation({
    mutationFn: async (data: Partial<UserGroup>) => {
      return apiRequest('/api/groups', { method: 'POST', data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/groups'] });
      resetNewGroup();
      toast({
        title: "Grup oluşturuldu",
        description: "Kullanıcı grubu başarıyla eklendi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Grup oluşturulurken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  // Grup silme
  const deleteGroupMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/groups/${id}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/groups'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Grup silindi",
        description: "Kullanıcı grubu başarıyla silindi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Grup silinirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  // Grup güncelleme
  const updateGroupMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<UserGroup> }) => {
      return apiRequest(`/api/groups/${id}`, { method: 'PUT', data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/groups'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setEditMode(null);
      toast({
        title: "Grup güncellendi",
        description: "Kullanıcı grubu başarıyla güncellendi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Grup güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  const handleCreateGroup = () => {
    if (!newGroup.name) {
      toast({
        title: "Hata",
        description: "Grup adı boş olamaz",
        variant: "destructive",
      });
      return;
    }
    createGroupMutation.mutate(newGroup);
  };

  const handleEditGroup = (group: UserGroup) => {
    setEditMode(group.id);
  };

  const handleUpdateGroup = (group: UserGroup) => {
    updateGroupMutation.mutate({ id: group.id, data: group });
  };

  const handleDeleteGroup = (id: number) => {
    if (window.confirm("Bu grubu silmek istediğinizden emin misiniz?")) {
      deleteGroupMutation.mutate(id);
    }
  };

  const handleCancelEdit = () => {
    setEditMode(null);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center">
          <LuUsers className="mr-2" /> Kullanıcı Grupları
        </CardTitle>
        <CardDescription>
          Kullanıcılarınızı kategorilere ayırarak daha etkili iletişim kurun
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Yeni grup oluşturma */}
          <div className="border rounded-lg p-4 bg-muted/30">
            <h3 className="font-medium mb-3 flex items-center">
              <LuPlus className="mr-2" size={18} /> Yeni Grup Ekle
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="new-group-name">Grup Adı</Label>
                <Input 
                  id="new-group-name" 
                  value={newGroup.name}
                  onChange={(e) => setNewGroup({...newGroup, name: e.target.value})}
                  placeholder="Grup adı"
                />
              </div>
              <div>
                <Label htmlFor="new-group-desc">Açıklama</Label>
                <Input 
                  id="new-group-desc" 
                  value={newGroup.description || ""}
                  onChange={(e) => setNewGroup({...newGroup, description: e.target.value})}
                  placeholder="Açıklama (isteğe bağlı)"
                />
              </div>
              <div>
                <Label htmlFor="new-group-color">Renk</Label>
                <div className="flex items-center gap-2">
                  {colorOptions.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      aria-label={option.label}
                      title={option.label}
                      onClick={() => setNewGroup({...newGroup, color: option.value})}
                      className={cn(
                        "w-6 h-6 rounded-full border transition-all",
                        option.className,
                        newGroup.color === option.value 
                          ? "ring-2 ring-offset-2 ring-primary" 
                          : "hover:scale-110"
                      )}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-4 flex justify-end">
              <Button
                onClick={handleCreateGroup}
                disabled={createGroupMutation.isPending}
              >
                {createGroupMutation.isPending ? "Ekleniyor..." : "Grup Ekle"}
              </Button>
            </div>
          </div>

          <Separator />

          {/* Grup listesi */}
          <div>
            <h3 className="font-medium mb-3">Gruplar</h3>
            {groups.length === 0 ? (
              <p className="text-muted-foreground text-center py-6">
                Henüz hiç grup oluşturmadınız
              </p>
            ) : (
              <ScrollArea className="h-[250px]">
                <div className="space-y-2">
                  {Array.isArray(groups) && groups.map((group: UserGroup) => (
                    <div key={group.id} className="border rounded-md p-3">
                      {editMode === group.id ? (
                        // Düzenleme modu
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <Label htmlFor={`edit-name-${group.id}`}>Grup Adı</Label>
                            <Input 
                              id={`edit-name-${group.id}`}
                              value={group.name}
                              onChange={(e) => {
                                if (Array.isArray(groups)) {
                                  const updatedGroups = [...groups];
                                  const index = updatedGroups.findIndex(g => g.id === group.id);
                                  updatedGroups[index] = {...group, name: e.target.value};
                                  queryClient.setQueryData(['/api/groups'], updatedGroups);
                                }
                              }}
                            />
                          </div>
                          <div>
                            <Label htmlFor={`edit-desc-${group.id}`}>Açıklama</Label>
                            <Input 
                              id={`edit-desc-${group.id}`}
                              value={group.description || ""}
                              onChange={(e) => {
                                if (Array.isArray(groups)) {
                                  const updatedGroups = [...groups];
                                  const index = updatedGroups.findIndex(g => g.id === group.id);
                                  updatedGroups[index] = {...group, description: e.target.value};
                                  queryClient.setQueryData(['/api/groups'], updatedGroups);
                                }
                              }}
                            />
                          </div>
                          <div>
                            <Label>Renk</Label>
                            <div className="flex items-center gap-2">
                              {colorOptions.map((option) => (
                                <button
                                  key={option.value}
                                  type="button"
                                  aria-label={option.label}
                                  title={option.label}
                                  onClick={() => {
                                    if (Array.isArray(groups)) {
                                      const updatedGroups = [...groups];
                                      const index = updatedGroups.findIndex(g => g.id === group.id);
                                      updatedGroups[index] = {...group, color: option.value};
                                      queryClient.setQueryData(['/api/groups'], updatedGroups);
                                    }
                                  }}
                                  className={cn(
                                    "w-5 h-5 rounded-full border transition-all",
                                    option.className,
                                    group.color === option.value 
                                      ? "ring-2 ring-offset-1 ring-primary" 
                                      : "hover:scale-110"
                                  )}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                      ) : (
                        // Görüntüleme modu
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div 
                              className="w-4 h-4 rounded-full" 
                              style={{ backgroundColor: group.color || "#4f46e5" }}
                            />
                            <div>
                              <h4 className="font-medium">{group.name}</h4>
                              {group.description && (
                                <p className="text-sm text-muted-foreground">{group.description}</p>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Düğmeler */}
                      <div className="flex justify-end gap-2 mt-2">
                        {editMode === group.id ? (
                          <>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={handleCancelEdit}
                            >
                              <LuX className="mr-1" size={16} /> İptal
                            </Button>
                            <Button 
                              size="sm"
                              onClick={() => handleUpdateGroup(group)}
                              disabled={updateGroupMutation.isPending}
                            >
                              <LuCheck className="mr-1" size={16} /> Kaydet
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditGroup(group)}
                            >
                              <LuPencil className="mr-1" size={16} /> Düzenle
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteGroup(group.id)}
                              disabled={deleteGroupMutation.isPending}
                            >
                              <LuTrash2 className="mr-1" size={16} /> Sil
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}