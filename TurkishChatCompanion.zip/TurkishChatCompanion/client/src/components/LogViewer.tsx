import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { formatDate } from "@/utils/dateUtils";
import { Log } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2, Save } from "lucide-react";

export default function LogViewer() {
  const { toast } = useToast();
  const [filter, setFilter] = useState<string>("all");

  const { data: logs = [] as Log[] } = useQuery<Log[]>({
    queryKey: ['/api/logs'],
    refetchInterval: 2000,  // Refresh logs every 2 seconds
  });

  const clearLogsMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/logs', { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
      toast({
        title: "Loglar temizlendi",
        description: "Tüm log kayıtları silindi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `Loglar temizlenemedi: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleClearLogs = () => {
    clearLogsMutation.mutate();
  };

  const handleSaveLogFile = async () => {
    try {
      const response = await fetch('/api/logs/export', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Loglar indirilemedi');
      }
      
      const logContent = await response.text();
      
      // Create and download the file
      const blob = new Blob([logContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      // Use a more readable format for the filename
      const today = new Date();
      a.download = `logs_${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Loglar indirildi",
        description: "Log kayıtları dosya olarak indirildi.",
      });
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      toast({
        title: "Hata",
        description: `Loglar indirilemedi: ${errorMessage}`,
        variant: "destructive",
      });
    }
  };

  // Filter logs based on selected filter
  const filteredLogs = logs.filter((log: Log) => 
    filter === "all" || log.type === filter
  );

  return (
    <Card className="bg-card overflow-hidden">
      <CardHeader className="border-b">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium">İşlem Logları</CardTitle>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleClearLogs}
            disabled={clearLogsMutation.isPending || logs.length === 0}
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Temizle
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]" style={{ background: '#1E1E2E' }}>
          <div className="p-4 space-y-2 font-mono text-sm">
            {filteredLogs.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                Henüz log kaydı bulunmuyor
              </div>
            ) : (
              filteredLogs.map((log: Log) => (
                <div 
                  key={log.id} 
                  className={`log-entry ${log.type} px-3 py-2 rounded border-l-4 ${
                    log.type === 'success' ? 'border-green-500 bg-green-900/20' : 
                    log.type === 'info' ? 'border-blue-500 bg-blue-900/20' : 
                    'border-red-500 bg-red-900/20'
                  }`}
                >
                  <span className="text-gray-400 text-xs mr-2">
                    {formatDate(log.timestamp)}
                  </span>
                  <span className={`${
                    log.type === 'success' ? 'text-green-400' : 
                    log.type === 'info' ? 'text-blue-400' : 
                    'text-red-400'
                  }`}>
                    [{log.type.toUpperCase()}]
                  </span>{' '}
                  <span className="text-gray-200">{log.message}</span>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
      
      <CardFooter className="border-t py-4 bg-muted/40">
        <div className="flex flex-wrap gap-2">
          <Button 
            variant="outline" 
            size="sm"
            className={filter === "all" ? "bg-muted" : ""}
            onClick={() => setFilter("all")}
          >
            Tümü
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            className={filter === "success" ? "border-green-300 text-green-700 bg-green-50" : ""}
            onClick={() => setFilter("success")}
          >
            Başarı
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            className={filter === "info" ? "border-blue-300 text-blue-700 bg-blue-50" : ""}
            onClick={() => setFilter("info")}
          >
            Bilgi
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            className={filter === "error" ? "border-red-300 text-red-700 bg-red-50" : ""}
            onClick={() => setFilter("error")}
          >
            Hata
          </Button>
          
          <div className="ml-auto">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleSaveLogFile}
              disabled={logs.length === 0}
            >
              <Save className="h-4 w-4 mr-1" />
              Kaydet
            </Button>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}
