import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge"; 
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserWithStatus } from "@shared/schema";

interface TestMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserWithStatus | null;
}

export default function TestMessageModal({ isOpen, onClose, user }: TestMessageModalProps) {
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("none");

  const { data: templates = [] } = useQuery({
    queryKey: ['/api/templates/categories'],
    enabled: isOpen
  });
  
  const { data: groups = [] } = useQuery({
    queryKey: ['/api/groups'],
    enabled: isOpen
  });

  useEffect(() => {
    if (user) {
      // Start with a default message
      setMessage(`Merhaba ${user.name}, size özel bir teklifimiz var!`);
      // Reset template selection
      setSelectedTemplate("none");
    }
  }, [user]);
  
  // Apply template when selected
  useEffect(() => {
    if (selectedTemplate && selectedTemplate !== "none" && Array.isArray(templates) && templates.length > 0) {
      const template: any = templates.find((t: any) => t.id.toString() === selectedTemplate);
      if (template) {
        // Replace placeholders
        let customMessage = template.template;
        customMessage = customMessage.replace(/{name}/g, user?.name || "");
        customMessage = customMessage.replace(/{phone}/g, user?.phone || "");
        setMessage(customMessage);
      }
    }
  }, [selectedTemplate, templates, user]);

  const sendTestMessageMutation = useMutation({
    mutationFn: async () => {
      if (!user) return;
      
      return apiRequest('/api/simulate/test', {
        method: 'POST',
        data: {
          phone: user.phone,
          name: user.name,
          message
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
      toast({
        title: "Test mesajı gönderildi",
        description: "Test mesajı başarıyla gönderildi.",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: `Test mesajı gönderilemedi: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleSend = () => {
    if (message.trim()) {
      sendTestMessageMutation.mutate();
    } else {
      toast({
        title: "Hata",
        description: "Boş mesaj gönderilemez.",
        variant: "destructive",
      });
    }
  };

  if (!user) return null;
  
  // Find group info for display
  const userGroup = user.groupId && Array.isArray(groups) ?
    groups.find((g: any) => g.id === user.groupId) : null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Test Mesajı Gönder</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label>Alıcı</Label>
            <div className="mt-1 flex items-center">
              <span className="font-medium">{user.name}</span>
              <span className="mx-2 text-muted-foreground">{user.phone}</span>
              
              {userGroup && (
                <Badge 
                  variant="outline" 
                  className="font-normal ml-auto"
                  style={{
                    backgroundColor: userGroup.color + "20", // 20% opacity
                    borderColor: userGroup.color,
                    color: userGroup.color
                  }}
                >
                  {userGroup.name}
                </Badge>
              )}
            </div>
          </div>
          
          {Array.isArray(templates) && templates.length > 0 && (
            <div>
              <Label htmlFor="templateSelect">Mesaj şablonu</Label>
              <Select
                value={selectedTemplate}
                onValueChange={setSelectedTemplate}
              >
                <SelectTrigger id="templateSelect" className="mt-1">
                  <SelectValue placeholder="Şablon seçin (isteğe bağlı)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Şablon seçin</SelectItem>
                  {templates.map((template: any) => (
                    <SelectItem key={template.id} value={template.id.toString()}>
                      <div className="flex items-center">
                        <span className="truncate mr-2">
                          {template.template.length > 30 
                            ? template.template.substring(0, 30) + "..." 
                            : template.template}
                        </span>
                        {template.categoryName && (
                          <Badge variant="outline" className="ml-auto text-xs">
                            {template.categoryName}
                          </Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          
          <div>
            <Label htmlFor="testMessage">Mesaj</Label>
            <Textarea
              id="testMessage"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="mt-1"
            />
          </div>
        </div>
        
        <DialogFooter className="sm:justify-end">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
          >
            İptal
          </Button>
          <Button
            type="button"
            onClick={handleSend}
            disabled={sendTestMessageMutation.isPending}
          >
            {sendTestMessageMutation.isPending ? "Gönderiliyor..." : "Gönder"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}