import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { RefreshCcw, Upload, Download, Search, Users } from "lucide-react";
import { UserWithStatus } from "@shared/schema";
import { downloadCSV } from "@/utils/fileUtils";

interface UserListProps {
  onTestUser: (user: UserWithStatus) => void;
}

export default function UserList({ onTestUser }: UserListProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterGroup, setFilterGroup] = useState("all");

  // Fetch users
  const { data: users = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/users'],
  });

  // Fetch groups
  const { data: groups = [] } = useQuery({
    queryKey: ['/api/groups'],
  });

  // Filter users based on search term, status, and group
  const filteredUsers = Array.isArray(users) ? users.filter((user: UserWithStatus) => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.phone.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || user.status === filterStatus;
    
    const matchesGroup = filterGroup === "all" || 
      (filterGroup === "none" && !user.groupId) || 
      (user.groupId?.toString() === filterGroup);
    
    return matchesSearch && matchesStatus && matchesGroup;
  }) : [];

  // Calculate counts
  const unsentCount = Array.isArray(users) ? users.filter((user: UserWithStatus) => user.status === "unsent").length : 0;

  // Upload CSV mutation
  const uploadCSVMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      
      const res = await fetch('/api/users/csv', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || res.statusText);
      }
      
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "CSV yüklendi",
        description: `${data.users.length} kullanıcı başarıyla içe aktarıldı.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: `CSV yüklenemedi: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadCSVMutation.mutate(file);
    }
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleExportCSV = async () => {
    try {
      const response = await fetch('/api/users/csv', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('CSV indirilemedi');
      }
      
      const csvContent = await response.text();
      downloadCSV(csvContent, 'users.csv');
      
      toast({
        title: "CSV dışa aktarıldı",
        description: "Kullanıcı listesi başarıyla CSV olarak indirildi.",
      });
    } catch (error: any) {
      toast({
        title: "Hata",
        description: `CSV dışa aktarılamadı: ${error.message || 'Bilinmeyen bir hata oluştu'}`,
        variant: "destructive",
      });
    }
  };

  const handleRefresh = () => {
    refetch();
    toast({
      title: "Liste yenilendi",
      description: "Kullanıcı listesi yenilendi.",
    });
  };

  return (
    <Card className="bg-card overflow-hidden">
      <CardHeader className="border-b">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium">Kullanıcı Listesi</CardTitle>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleRefresh}
              disabled={isLoading}
            >
              <RefreshCcw className="h-4 w-4 mr-1" />
              Yenile
            </Button>
            
            <input
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              ref={fileInputRef}
              className="hidden"
            />
            
            <Button 
              variant="link" 
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadCSVMutation.isPending}
            >
              <Upload className="h-4 w-4 mr-1" />
              CSV Yükle
            </Button>
          </div>
        </div>
        
        <div className="mt-4 flex flex-col md:flex-row md:items-center gap-3">
          <div className="relative grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Kullanıcı Ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Select 
              value={filterStatus} 
              onValueChange={setFilterStatus}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Tümü" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tüm Durumlar</SelectItem>
                <SelectItem value="unsent">Gönderilmemiş</SelectItem>
                <SelectItem value="sent">Gönderilmiş</SelectItem>
              </SelectContent>
            </Select>
            
            <Select 
              value={filterGroup} 
              onValueChange={setFilterGroup}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Tüm Gruplar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tüm Gruplar</SelectItem>
                <SelectItem value="none">Grupsuz</SelectItem>
                {Array.isArray(groups) && groups.map((group: any) => (
                  <SelectItem key={group.id} value={group.id.toString()}>
                    {group.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Ad</TableHead>
              <TableHead>Telefon</TableHead>
              <TableHead>Grup</TableHead>
              <TableHead>Durum</TableHead>
              <TableHead>Son Gönderim</TableHead>
              <TableHead className="text-right">İşlem</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  {isLoading ? "Yükleniyor..." : "Kullanıcı bulunamadı"}
                </TableCell>
              </TableRow>
            ) : (
              filteredUsers.map((user: UserWithStatus) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.phone}</TableCell>
                  <TableCell>
                    {user.groupName ? (
                      <Badge 
                        variant="outline" 
                        className="font-normal"
                        style={{
                          backgroundColor: 
                            Array.isArray(groups) ? 
                            (groups.find((g: any) => g.id === user.groupId)?.color + "20" || "#e5e7eb20") : "#e5e7eb20", // 20% opacity
                          borderColor: 
                            Array.isArray(groups) ? 
                            (groups.find((g: any) => g.id === user.groupId)?.color || "#e5e7eb") : "#e5e7eb",
                          color: 
                            Array.isArray(groups) ? 
                            (groups.find((g: any) => g.id === user.groupId)?.color || "#71717a") : "#71717a"
                        }}
                      >
                        {user.groupName}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground text-sm">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.status === 'unsent' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {user.status === 'unsent' ? 'Gönderilmemiş' : 'Gönderilmiş'}
                    </span>
                  </TableCell>
                  <TableCell>{user.lastSent || '-'}</TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="link" 
                      className="text-primary hover:text-primary/90"
                      onClick={() => onTestUser(user)}
                    >
                      Test Et
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      <CardFooter className="border-t py-4 bg-muted/40">
        <div className="flex justify-between items-center w-full">
          <div className="text-sm text-muted-foreground">
            Toplam {Array.isArray(users) ? users.length : 0} kullanıcı ({unsentCount} gönderilmemiş)
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleExportCSV}
          >
            <Download className="h-4 w-4 mr-1" />
            CSV İndir
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}