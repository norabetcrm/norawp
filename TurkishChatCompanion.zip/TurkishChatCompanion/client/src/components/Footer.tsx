export default function Footer() {
  return (
    <footer className="bg-card mt-12 py-6 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="text-sm text-muted-foreground">
            WhatsApp Mesaj Gönderim Simülatörü &copy; {new Date().getFullYear()}
          </div>
          <div className="text-sm text-muted-foreground">
            v1.0.0
          </div>
        </div>
      </div>
    </footer>
  );
}
