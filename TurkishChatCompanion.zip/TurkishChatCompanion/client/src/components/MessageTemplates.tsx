import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { PlusCircle, Pencil, Trash2, X, Check } from "lucide-react";

export default function MessageTemplates() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newTemplate, setNewTemplate] = useState("");
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | null>(null);
  const [editingTemplate, setEditingTemplate] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("none");
  const [editingCategory, setEditingCategory] = useState<number | null>(null);
  
  // Templates data with categories
  const { data: templates = [] } = useQuery({
    queryKey: ['/api/templates/categories'],
    staleTime: 10000,
  });

  // Categories data
  const { data: categories = [] } = useQuery({
    queryKey: ['/api/categories'],
    staleTime: 10000,
  });

  // Create template mutation
  const createTemplateMutation = useMutation({
    mutationFn: async (data: { template: string, categoryId: number | null }) => {
      return apiRequest('/api/templates', { method: 'POST', data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/templates/categories'] });
      setNewTemplate("");
      setSelectedCategory("none");
      toast({
        title: "Şablon eklendi",
        description: "Yeni mesaj şablonu başarıyla eklendi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Şablon eklenirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  // Update template mutation
  const updateTemplateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: { template: string, categoryId: number | null } }) => {
      return apiRequest(`/api/templates/${id}`, { method: 'PUT', data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/templates/categories'] });
      setSelectedTemplateId(null);
      setEditingTemplate("");
      setEditingCategory(null);
      toast({
        title: "Şablon güncellendi",
        description: "Mesaj şablonu başarıyla güncellendi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Şablon güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  // Delete template mutation
  const deleteTemplateMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/templates/${id}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/templates/categories'] });
      toast({
        title: "Şablon silindi",
        description: "Mesaj şablonu başarıyla silindi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Şablon silinirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  const handleCreateTemplate = () => {
    if (newTemplate.trim() === "") {
      toast({
        title: "Hata",
        description: "Şablon boş olamaz.",
        variant: "destructive",
      });
      return;
    }
    
    // Convert string categoryId to number or null
    const categoryId = selectedCategory === "none" ? null : parseInt(selectedCategory);
    
    createTemplateMutation.mutate({ 
      template: newTemplate,
      categoryId
    });
  };

  const handleUpdateTemplate = () => {
    if (editingTemplate.trim() === "" || !selectedTemplateId) {
      return;
    }
    
    updateTemplateMutation.mutate({ 
      id: selectedTemplateId, 
      data: { 
        template: editingTemplate,
        categoryId: editingCategory
      } 
    });
  };

  const handleDeleteTemplate = (id: number) => {
    if (window.confirm("Bu şablonu silmek istediğinizden emin misiniz?")) {
      deleteTemplateMutation.mutate(id);
    }
  };

  const startEditing = (template: any) => {
    setSelectedTemplateId(template.id);
    setEditingTemplate(template.template);
    setEditingCategory(template.categoryId);
  };

  const cancelEditing = () => {
    setSelectedTemplateId(null);
    setEditingTemplate("");
    setEditingCategory(null);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Mesaj Şablonları</CardTitle>
        <CardDescription>
          İsim değişkeni için {"{name}"} ekleyebilirsiniz
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* New Template Input */}
          <div className="space-y-2">
            <div className="space-y-1">
              <Input
                placeholder="Yeni şablon ekleyin... Örn: Merhaba {name}, size özel fırsatlar!"
                value={newTemplate}
                onChange={(e) => setNewTemplate(e.target.value)}
              />
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="category">Kategori</Label>
              <Select 
                value={selectedCategory} 
                onValueChange={(value) => setSelectedCategory(value)}
              >
                <SelectTrigger id="category">
                  <SelectValue placeholder="Kategori seçin (isteğe bağlı)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Kategorisiz</SelectItem>
                  {Array.isArray(categories) && categories.map((category: any) => (
                    <SelectItem key={category.id} value={category.id.toString()}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              onClick={handleCreateTemplate}
              disabled={createTemplateMutation.isPending}
              className="w-full"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              {createTemplateMutation.isPending ? "Ekleniyor..." : "Şablon Ekle"}
            </Button>
          </div>

          <Separator />

          {/* Template List */}
          <div>
            <h3 className="font-medium mb-2">Mevcut Şablonlar</h3>
            {!Array.isArray(templates) || templates.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">
                Henüz hiç şablon eklenmemiş
              </p>
            ) : (
              <ScrollArea className="h-[300px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mesaj Şablonu</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {templates.map((template: any) => (
                      <TableRow key={template.id}>
                        <TableCell>
                          {selectedTemplateId === template.id ? (
                            <Input
                              value={editingTemplate}
                              onChange={(e) => setEditingTemplate(e.target.value)}
                              className="mb-2"
                            />
                          ) : (
                            template.template
                          )}
                        </TableCell>
                        <TableCell>
                          {selectedTemplateId === template.id ? (
                            <Select 
                              value={editingCategory?.toString() || "none"} 
                              onValueChange={(value) => setEditingCategory(value === "none" ? null : parseInt(value))}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Kategori seçin" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="none">Kategorisiz</SelectItem>
                                {Array.isArray(categories) && categories.map((category: any) => (
                                  <SelectItem key={category.id} value={category.id.toString()}>
                                    {category.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            template.categoryName ? (
                              <Badge variant="outline">
                                {template.categoryName}
                              </Badge>
                            ) : (
                              <span className="text-muted-foreground text-sm">Kategorisiz</span>
                            )
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {selectedTemplateId === template.id ? (
                            <div className="flex justify-end gap-2">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={cancelEditing}
                              >
                                <X className="h-4 w-4 mr-1" />
                                İptal
                              </Button>
                              <Button 
                                size="sm" 
                                onClick={handleUpdateTemplate}
                                disabled={updateTemplateMutation.isPending}
                              >
                                <Check className="h-4 w-4 mr-1" />
                                {updateTemplateMutation.isPending ? "..." : "Kaydet"}
                              </Button>
                            </div>
                          ) : (
                            <div className="flex justify-end gap-2">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={() => startEditing(template)}
                              >
                                <Pencil className="h-4 w-4 mr-1" />
                                Düzenle
                              </Button>
                              <Button 
                                size="sm" 
                                variant="destructive" 
                                onClick={() => handleDeleteTemplate(template.id)}
                                disabled={deleteTemplateMutation.isPending}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Sil
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}