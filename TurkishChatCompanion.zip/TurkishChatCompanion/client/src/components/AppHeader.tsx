import { useTheme } from "@/components/ui/theme-provider";
import { Button } from "@/components/ui/button";
import { Moon, Sun, Smartphone } from "lucide-react";
import { Link } from "wouter";

export default function AppHeader() {
  const { theme, setTheme } = useTheme();

  return (
    <header className="bg-card shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center cursor-pointer">
                <Smartphone className="h-8 w-8 text-green-500" />
                <h1 className="ml-2 text-xl font-semibold text-foreground">WhatsApp Mesaj Gönderim Simülatörü</h1>
              </div>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              aria-label="Karanlık modu aç/kapa"
            >
              {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </Button>
            <Link href="/yardim">
              <span className="text-primary hover:text-primary-foreground/90 cursor-pointer">Yardım</span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
