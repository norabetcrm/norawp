import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

import { TemplateCategory } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { LuPlus, LuTrash2, LuLayoutTemplate, LuPencil, LuCheck, LuX } from "react-icons/lu";

export default function TemplateCategories() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState<number | null>(null);
  const [newCategory, setNewCategory] = useState<Partial<TemplateCategory>>({
    name: "",
    description: ""
  });
  
  // Form temizleme
  const resetNewCategory = () => {
    setNewCategory({
      name: "",
      description: ""
    });
  };
  
  // Şablon kategorilerini çek
  const { data: categories = [] } = useQuery<TemplateCategory[]>({
    queryKey: ['/api/categories'],
    staleTime: 10000,
  });

  // Şablonları çek (şablon sayılarını göstermek için)
  const { data: templates = [] } = useQuery<any[]>({
    queryKey: ['/api/templates/categories'],
    staleTime: 10000,
  });

  // Yeni kategori oluşturma
  const createCategoryMutation = useMutation({
    mutationFn: async (data: Partial<TemplateCategory>) => {
      return apiRequest('/api/categories', { method: 'POST', data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      resetNewCategory();
      toast({
        title: "Kategori oluşturuldu",
        description: "Şablon kategorisi başarıyla eklendi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Kategori oluşturulurken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  // Kategori silme
  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/categories/${id}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/templates/categories'] });
      toast({
        title: "Kategori silindi",
        description: "Şablon kategorisi başarıyla silindi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Kategori silinirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  // Kategori güncelleme
  const updateCategoryMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<TemplateCategory> }) => {
      return apiRequest(`/api/categories/${id}`, { method: 'PUT', data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      queryClient.invalidateQueries({ queryKey: ['/api/templates/categories'] });
      setEditMode(null);
      toast({
        title: "Kategori güncellendi",
        description: "Şablon kategorisi başarıyla güncellendi.",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Kategori güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    }
  });

  const handleCreateCategory = () => {
    if (!newCategory.name) {
      toast({
        title: "Hata",
        description: "Kategori adı boş olamaz",
        variant: "destructive",
      });
      return;
    }
    createCategoryMutation.mutate(newCategory);
  };

  const handleEditCategory = (category: TemplateCategory) => {
    setEditMode(category.id);
  };

  const handleUpdateCategory = (category: TemplateCategory) => {
    updateCategoryMutation.mutate({ id: category.id, data: category });
  };

  const handleDeleteCategory = (id: number) => {
    if (window.confirm("Bu kategoriyi silmek istediğinizden emin misiniz?")) {
      deleteCategoryMutation.mutate(id);
    }
  };

  const handleCancelEdit = () => {
    setEditMode(null);
  };

  // Bir kategorideki şablon sayısını hesapla
  const getTemplateCountByCategory = (categoryId: number) => {
    return Array.isArray(templates) ? templates.filter(template => template.categoryId === categoryId).length : 0;
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center">
          <LuLayoutTemplate className="mr-2" /> Şablon Kategorileri
        </CardTitle>
        <CardDescription>
          Mesaj şablonlarınızı kategorilere ayırarak daha kolay yönetin
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Yeni kategori oluşturma */}
          <div className="border rounded-lg p-4 bg-muted/30">
            <h3 className="font-medium mb-3 flex items-center">
              <LuPlus className="mr-2" size={18} /> Yeni Kategori Ekle
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="new-category-name">Kategori Adı</Label>
                <Input 
                  id="new-category-name" 
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({...newCategory, name: e.target.value})}
                  placeholder="Kategori adı"
                />
              </div>
              <div>
                <Label htmlFor="new-category-desc">Açıklama</Label>
                <Input 
                  id="new-category-desc" 
                  value={newCategory.description || ""}
                  onChange={(e) => setNewCategory({...newCategory, description: e.target.value})}
                  placeholder="Açıklama (isteğe bağlı)"
                />
              </div>
            </div>
            <div className="mt-4 flex justify-end">
              <Button
                onClick={handleCreateCategory}
                disabled={createCategoryMutation.isPending}
              >
                {createCategoryMutation.isPending ? "Ekleniyor..." : "Kategori Ekle"}
              </Button>
            </div>
          </div>

          <Separator />

          {/* Kategori listesi */}
          <div>
            <h3 className="font-medium mb-3">Kategoriler</h3>
            {categories.length === 0 ? (
              <p className="text-muted-foreground text-center py-6">
                Henüz hiç kategori oluşturmadınız
              </p>
            ) : (
              <ScrollArea className="h-[250px]">
                <div className="space-y-2">
                  {categories.map((category: TemplateCategory) => (
                    <div key={category.id} className="border rounded-md p-3">
                      {editMode === category.id ? (
                        // Düzenleme modu
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor={`edit-name-${category.id}`}>Kategori Adı</Label>
                            <Input 
                              id={`edit-name-${category.id}`}
                              value={category.name}
                              onChange={(e) => {
                                if (Array.isArray(categories)) {
                                  const updatedCategories = [...categories];
                                  const index = updatedCategories.findIndex(c => c.id === category.id);
                                  updatedCategories[index] = {...category, name: e.target.value};
                                  queryClient.setQueryData(['/api/categories'], updatedCategories);
                                }
                              }}
                            />
                          </div>
                          <div>
                            <Label htmlFor={`edit-desc-${category.id}`}>Açıklama</Label>
                            <Input 
                              id={`edit-desc-${category.id}`}
                              value={category.description || ""}
                              onChange={(e) => {
                                if (Array.isArray(categories)) {
                                  const updatedCategories = [...categories];
                                  const index = updatedCategories.findIndex(c => c.id === category.id);
                                  updatedCategories[index] = {...category, description: e.target.value};
                                  queryClient.setQueryData(['/api/categories'], updatedCategories);
                                }
                              }}
                            />
                          </div>
                        </div>
                      ) : (
                        // Görüntüleme modu
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div>
                              <h4 className="font-medium flex items-center">
                                {category.name} 
                                <Badge variant="outline" className="ml-2">
                                  {getTemplateCountByCategory(category.id)} şablon
                                </Badge>
                              </h4>
                              {category.description && (
                                <p className="text-sm text-muted-foreground">{category.description}</p>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Düğmeler */}
                      <div className="flex justify-end gap-2 mt-2">
                        {editMode === category.id ? (
                          <>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={handleCancelEdit}
                            >
                              <LuX className="mr-1" size={16} /> İptal
                            </Button>
                            <Button 
                              size="sm"
                              onClick={() => handleUpdateCategory(category)}
                              disabled={updateCategoryMutation.isPending}
                            >
                              <LuCheck className="mr-1" size={16} /> Kaydet
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditCategory(category)}
                            >
                              <LuPencil className="mr-1" size={16} /> Düzenle
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteCategory(category.id)}
                              disabled={deleteCategoryMutation.isPending}
                            >
                              <LuTrash2 className="mr-1" size={16} /> Sil
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}