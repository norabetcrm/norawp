import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  PlayCircle, 
  StopCircle, 
  Users, 
  RefreshCw,
  AlertCircle
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ControlsProps {
  operationRunning: boolean;
  setOperationRunning: (running: boolean) => void;
  progress: {
    current: number;
    total: number;
    percentage: number;
  };
  setProgress: (progress: { current: number; total: number; percentage: number }) => void;
}

export default function Controls({
  operationRunning,
  setOperationRunning,
  progress,
  setProgress
}: ControlsProps) {
  const { toast } = useToast();
  const [pollInterval, setPollInterval] = useState<NodeJS.Timeout | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<string>("all");

  const { data: config } = useQuery({
    queryKey: ['/api/config'],
  });

  const { data: usersData } = useQuery({
    queryKey: ['/api/users'],
  });
  
  const { data: groups = [] } = useQuery({
    queryKey: ['/api/groups'],
  });

  // Calculate daily limit
  const dailyLimit = config && usersData && Array.isArray(usersData) ? 
    Math.min((config as any).dailyLimitPerAccount * (config as any).accounts, usersData.length) : 0;
  
  // Count unprocessed users by group
  const unsentCountByGroup = () => {
    if (!usersData || !Array.isArray(usersData)) return { total: 0, byGroup: {} };
    
    const unsent = usersData.filter((user: any) => user.status === "unsent");
    const total = unsent.length;
    
    const byGroup: Record<string, number> = {};
    
    // Count by group
    if (Array.isArray(groups) && groups.length > 0) {
      // Initialize with 0 for all groups
      groups.forEach((group: any) => {
        byGroup[group.id] = 0;
      });
      
      // Count unsent users in each group
      unsent.forEach((user: any) => {
        if (user.groupId) {
          byGroup[user.groupId] = (byGroup[user.groupId] || 0) + 1;
        }
      });
    }
    
    return { total, byGroup };
  };
  
  const unsentStats = unsentCountByGroup();

  // Start operation mutation
  const startOperationMutation = useMutation({
    mutationFn: async () => {
      const data = selectedGroup && selectedGroup !== "all" ? { groupId: selectedGroup } : {};
      return apiRequest('/api/simulate/start', { 
        method: 'POST', 
        data
      });
    },
    onSuccess: (data) => {
      setOperationRunning(true);
      
      const groupName = selectedGroup && selectedGroup !== "all" && Array.isArray(groups) ? 
        groups.find((g: any) => g.id.toString() === selectedGroup)?.name : null;
        
      toast({
        title: "İşlem başlatıldı",
        description: groupName ? 
          `"${groupName}" grubundaki ${data.totalSelected} kullanıcıya mesaj gönderimi başlatılıyor.` : 
          `${data.totalSelected} kullanıcıya mesaj gönderimi başlatılıyor.`,
      });
      
      // Setup progress tracking
      setProgress({
        current: 0,
        total: data.totalSelected,
        percentage: 0
      });
      
      // Refresh data every 2 seconds to track progress
      const interval = setInterval(() => {
        queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
        queryClient.invalidateQueries({ queryKey: ['/api/users'] });
        queryClient.invalidateQueries({ queryKey: ['/api/history'] });
      }, 2000);
      
      setPollInterval(interval);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: `İşlem başlatılamadı: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update progress based on logs
  const { data: logs = [] } = useQuery({
    queryKey: ['/api/logs'],
    refetchInterval: operationRunning ? 2000 : false
  });

  useEffect(() => {
    if (operationRunning && Array.isArray(logs) && logs.length > 0 && progress.total > 0) {
      // Count success messages to track progress
      const successCount = logs.filter((log: any) => 
        log.type === 'success' && 
        log.message.includes('Mesaj gönderildi')
      ).length;
      
      // Check if operation is complete
      const completionLog = logs.find((log: any) => 
        log.type === 'info' && 
        log.message.includes('Gönderim simülasyonu tamamlandı')
      );
      
      if (completionLog) {
        setOperationRunning(false);
        if (pollInterval) {
          clearInterval(pollInterval);
          setPollInterval(null);
        }
        
        // Set progress to 100%
        setProgress({
          current: progress.total,
          total: progress.total,
          percentage: 100
        });
        
        // Refresh data one last time
        queryClient.invalidateQueries({ queryKey: ['/api/users'] });
        queryClient.invalidateQueries({ queryKey: ['/api/history'] });
        
        toast({
          title: "İşlem tamamlandı",
          description: `${progress.total} kullanıcıya mesaj gönderimi tamamlandı.`,
        });
      } else {
        // Update progress
        const percentage = Math.min(Math.round((successCount / progress.total) * 100), 100);
        setProgress({
          current: successCount,
          total: progress.total,
          percentage
        });
      }
    }
  }, [logs, operationRunning, progress.total, pollInterval]);

  const handleStart = () => {
    startOperationMutation.mutate();
  };

  const handleStop = () => {
    // This is just a visual stop since the backend operation
    // can't be stopped once started in this implementation
    setOperationRunning(false);
    if (pollInterval) {
      clearInterval(pollInterval);
      setPollInterval(null);
    }
    
    toast({
      title: "İşlem durduruldu",
      description: "Mesaj gönderim işlemi durduruldu.",
    });
  };
  
  const handleRefreshDataQueries = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    queryClient.invalidateQueries({ queryKey: ['/api/groups'] });
    
    toast({
      title: "Veriler yenilendi",
      description: "Kullanıcı ve grup bilgileri yenilendi.",
    });
  };

  return (
    <Card className="bg-card">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Kontrol Paneli</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="text-sm font-medium text-muted-foreground">
              <span>Günlük Limit: </span>
              <span className="text-primary">{dailyLimit}</span>
              <span> mesaj</span>
            </div>
            
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleRefreshDataQueries}
              disabled={operationRunning}
              className="h-8"
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              Yenile
            </Button>
          </div>
          
          {/* Group selection */}
          {Array.isArray(groups) && groups.length > 0 && (
            <div className="mb-1">
              <Select
                value={selectedGroup}
                onValueChange={setSelectedGroup}
                disabled={operationRunning}
              >
                <SelectTrigger className="w-full">
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2 opacity-70" />
                    <SelectValue placeholder="Tüm kullanıcılar" />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm kullanıcılar</SelectItem>
                  {groups.map((group: any) => (
                    <SelectItem 
                      key={group.id} 
                      value={group.id.toString()}
                    >
                      {group.name} 
                      {unsentStats.byGroup && unsentStats.byGroup[group.id] > 0 && (
                        <span className="ml-2 text-xs opacity-70">
                          ({unsentStats.byGroup[group.id]})
                        </span>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          
          {/* Warning if no unsent users */}
          {unsentStats.total === 0 && (
            <Alert variant="destructive" className="py-2">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Gönderilmemiş kullanıcı bulunamadı!
              </AlertDescription>
            </Alert>
          )}
          
          <div className="grid grid-cols-2 gap-4">
            <Button
              variant="default"
              className="bg-green-600 hover:bg-green-700"
              onClick={handleStart}
              disabled={operationRunning || startOperationMutation.isPending || unsentStats.total === 0}
            >
              <PlayCircle className="mr-2 h-4 w-4" />
              {startOperationMutation.isPending ? "Başlatılıyor..." : "Başlat"}
            </Button>
            
            <Button
              variant="destructive"
              onClick={handleStop}
              disabled={!operationRunning}
            >
              <StopCircle className="mr-2 h-4 w-4" />
              Durdur
            </Button>
          </div>
          
          {/* Progress Bar */}
          {(operationRunning || progress.percentage > 0) && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>{progress.current}/{progress.total} kişi</span>
                <span>{progress.percentage}%</span>
              </div>
              <Progress value={progress.percentage} className="h-2.5" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}