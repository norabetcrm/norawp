import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Check, BarChart2, Clock, Users } from "lucide-react";
import { UserWithStatus, MessageHistoryEntry, Config } from "@shared/schema";

export default function Stats() {
  const { data: users = [] } = useQuery<UserWithStatus[]>({
    queryKey: ['/api/users'],
  });

  const { data: history = [] } = useQuery<MessageHistoryEntry[]>({
    queryKey: ['/api/history'],
  });

  const { data: config } = useQuery<Config>({
    queryKey: ['/api/config'],
  });

  // Hesaplanan istatistikler
  const totalUsers = users.length;
  const sentUsers = users.filter((user: UserWithStatus) => user.status === "sent").length;
  const unsentUsers = users.filter((user: UserWithStatus) => user.status === "unsent").length;
  const sentPercentage = totalUsers > 0 ? Math.round((sentUsers / totalUsers) * 100) : 0;
  
  const dailyCapacity = config ? config.dailyLimitPerAccount * config.accounts : 0;
  const capacityUsagePercentage = dailyCapacity > 0 ? Math.min(100, Math.round((sentUsers / dailyCapacity) * 100)) : 0;
  
  // Son 24 saatte gönderilen mesajlar
  const today = new Date();
  const oneDayAgo = new Date(today);
  oneDayAgo.setDate(today.getDate() - 1);
  
  const messagesSentToday = history.filter((entry: MessageHistoryEntry) => {
    const entryDate = new Date(entry.sentDate);
    return entryDate >= oneDayAgo;
  }).length;

  return (
    <Card className="bg-card">
      <CardHeader>
        <CardTitle className="text-lg font-medium flex items-center">
          <BarChart2 className="mr-2 h-5 w-5" />
          İstatistikler
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground flex items-center">
                <Users className="mr-1 h-4 w-4" />
                Toplam Kişi
              </span>
              <span className="font-medium">{totalUsers}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground flex items-center">
                <Check className="mr-1 h-4 w-4" />
                Gönderilmiş
              </span>
              <span className="font-medium">{sentUsers}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground flex items-center">
                <Clock className="mr-1 h-4 w-4" />
                Gönderilmemiş
              </span>
              <span className="font-medium">{unsentUsers}</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Günlük Kapasite</span>
              <span className="font-medium">{dailyCapacity}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Son 24 Saat</span>
              <span className="font-medium">{messagesSentToday}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Kapasite Kullanımı</span>
              <span className="font-medium">{capacityUsagePercentage}%</span>
            </div>
          </div>
        </div>
        
        <div className="mt-6 space-y-4">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground">Kişi Gönderim Durumu</span>
              <span>{sentPercentage}%</span>
            </div>
            <Progress value={sentPercentage} className="h-2" />
          </div>
          
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground">Günlük Kapasite Kullanımı</span>
              <span>{capacityUsagePercentage}%</span>
            </div>
            <Progress 
              value={capacityUsagePercentage} 
              className={`h-2 ${capacityUsagePercentage > 90 ? 'bg-red-200' : 'bg-green-200'}`} 
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}