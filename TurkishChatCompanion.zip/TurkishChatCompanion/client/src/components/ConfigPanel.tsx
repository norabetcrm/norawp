import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const configSchema = z.object({
  dailyLimitPerAccount: z.coerce.number().min(1).max(1000),
  accounts: z.coerce.number().min(1).max(20),
  messageDelayMin: z.coerce.number().min(1000).step(1000),
  messageDelayMax: z.coerce.number().min(1000).step(1000)
}).refine(data => data.messageDelayMax > data.messageDelayMin, {
  message: "Maximum delay must be greater than minimum delay",
  path: ["messageDelayMax"]
});

type ConfigFormValues = z.infer<typeof configSchema>;

export default function ConfigPanel() {
  const { toast } = useToast();

  const { data: config, isLoading } = useQuery({
    queryKey: ['/api/config'],
  });

  const form = useForm<ConfigFormValues>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      dailyLimitPerAccount: 100,
      accounts: 5,
      messageDelayMin: 30000,
      messageDelayMax: 60000
    }
  });

  // Update form when config data is loaded
  useEffect(() => {
    if (config) {
      form.reset({
        dailyLimitPerAccount: config.dailyLimitPerAccount,
        accounts: config.accounts,
        messageDelayMin: config.messageDelayMin,
        messageDelayMax: config.messageDelayMax
      });
    }
  }, [config, form]);

  const updateConfigMutation = useMutation({
    mutationFn: async (values: ConfigFormValues) => {
      const res = await apiRequest('PUT', '/api/config', values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/config'] });
      toast({
        title: "Yapılandırma kaydedildi",
        description: "Yapılandırma ayarları başarıyla güncellendi.",
      });
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: `Yapılandırma kaydedilemedi: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  function onSubmit(values: ConfigFormValues) {
    updateConfigMutation.mutate(values);
  }

  return (
    <Card className="bg-card">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Konfigürasyon</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="dailyLimitPerAccount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Günlük Limit (Hesap Başına)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      max={1000}
                      placeholder="100"
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="accounts"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Hesap Sayısı</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      max={20}
                      placeholder="5"
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="messageDelayMin"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Min. Gecikme (ms)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1000}
                      step={1000}
                      placeholder="30000"
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="messageDelayMax"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Max. Gecikme (ms)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1000}
                      step={1000}
                      placeholder="60000"
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || updateConfigMutation.isPending}
            >
              Ayarları Kaydet
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
