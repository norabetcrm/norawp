import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Trash2 } from "lucide-react";

export default function HistoryViewer() {
  const { toast } = useToast();

  const { data: history = [], isLoading } = useQuery({
    queryKey: ['/api/history'],
  });

  const clearHistoryMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', '/api/history');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/history'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] }); // Also refresh users to update status
      toast({
        title: "Geçmiş temizlendi",
        description: "Tüm gönderim geçmişi silindi.",
      });
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: `Geçmiş temizlenemedi: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleClearHistory = () => {
    clearHistoryMutation.mutate();
  };

  return (
    <Card className="bg-card overflow-hidden">
      <CardHeader className="border-b">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium">Gönderim Geçmişi</CardTitle>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleClearHistory}
            disabled={clearHistoryMutation.isPending || history.length === 0}
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Geçmişi Temizle
          </Button>
        </div>
      </CardHeader>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tarih</TableHead>
              <TableHead>Telefon</TableHead>
              <TableHead>Ad</TableHead>
              <TableHead>Mesaj</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {history.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                  {isLoading ? "Yükleniyor..." : "Henüz gönderim geçmişi bulunmuyor"}
                </TableCell>
              </TableRow>
            ) : (
              history.map((entry) => (
                <TableRow key={entry.id}>
                  <TableCell>{new Date(entry.sentDate).toLocaleDateString()}</TableCell>
                  <TableCell>{entry.phone}</TableCell>
                  <TableCell className="font-medium">{entry.name}</TableCell>
                  <TableCell className="max-w-xs truncate">
                    {entry.message}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      <CardFooter className="border-t py-4 bg-muted/40">
        <div className="text-sm text-muted-foreground">
          Toplam {history.length} kayıt
        </div>
      </CardFooter>
    </Card>
  );
}
